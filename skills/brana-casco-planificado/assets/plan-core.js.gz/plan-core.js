/* ===== geo.js ===== */
/* ============================================================================
   Geometria de superficies desenvolviveis e planificacao de chapas.

   TORCAO DA GERATRIZ
   Uma superficie regrada e desenvolvivel quando o plano tangente e o MESMO ao
   longo de toda a geratriz. Para a geratriz que liga A(u) a B(v):
       nA = A'(u) x (B-A)      nB = B'(v) x (B-A)
   e a medida de nao-desenvolvibilidade e o angulo entre nA e nB — a TORCAO da
   geratriz, em graus. Zero em toda a faixa = desenvolvivel.

   A torcao depende de QUAL geratriz se escolhe. Testar as geratrizes de baliza
   (x constante) so diz que aquele regramento nao serve. A pergunta certa e se
   EXISTE regramento com torcao nula, e isso se responde procurando, para cada
   u, a raiz de torcao(u,.)=0 sobre B e vendo se as raizes formam um caminho
   monotono de popa a proa.

   PLANIFICACAO — tres armadilhas que custaram um teste cada
   1. Uma FAIXA DE QUADRILATEROS nao tem vertice interno, e malha sem vertice
      interno sempre planifica com erro zero: a curvatura gaussiana discreta
      mora nos vertices internos. Por isso a chapa e malhada tambem NA LARGURA.
   2. A metrica intrinseca de uma malha e dada SO pelos comprimentos das
      ARESTAS da triangulacao. Usar a distancia entre dois vertices que nao sao
      vizinhos e usar uma corda que atravessa o solido por dentro — e isso
      encurva a chapa planificada de um cilindro, que devia sair reta.
   3. Uma face quadrilatera tem UMA diagonal na triangulacao, nao duas. Travar
      as duas impoe uma rigidez que a superficie nao tem.

   Convencao da malha: P[i][j], i ao longo do comprimento, j na largura.
   Triangulacao pela diagonal (i+1,j)-(i,j+1):
       T1(i,j) = (i,j), (i+1,j), (i,j+1)
       T2(i,j) = (i+1,j), (i+1,j+1), (i,j+1)
   ========================================================================== */

/* --------------------------------------------------------------- vetores -- */
function sub(a, b){ return [a[0]-b[0], a[1]-b[1], a[2]-b[2]]; }
function add(a, b){ return [a[0]+b[0], a[1]+b[1], a[2]+b[2]]; }
function mul(a, s){ return [a[0]*s, a[1]*s, a[2]*s]; }
function cross(a, b){
  return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
}
function dot(a, b){ return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]; }
function norm(a){ return Math.sqrt(dot(a, a)); }
function unit(a){ var n = norm(a); return n > 1e-14 ? mul(a, 1/n) : [0,0,0]; }
function lerp3(a, b, t){ return [a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t, a[2]+(b[2]-a[2])*t]; }
function dist(a, b){ return norm(sub(a, b)); }
function d2(p, q){ return Math.hypot(p[0]-q[0], p[1]-q[1]); }

/* ------------------------------------------------------ curva amostrada --- */
function tangentes(P){
  var n = P.length, T = new Array(n), i, k, d;
  for(i=0;i<n;i++){
    if(i === 0 && n >= 3){                          /* -3P0 +4P1 -P2 */
      d = [ -3*P[0][0] + 4*P[1][0] - P[2][0],
            -3*P[0][1] + 4*P[1][1] - P[2][1],
            -3*P[0][2] + 4*P[1][2] - P[2][2] ];
    } else if(i === n-1 && n >= 3){                 /* 3Pn -4Pn-1 +Pn-2 */
      d = [ 3*P[n-1][0] - 4*P[n-2][0] + P[n-3][0],
            3*P[n-1][1] - 4*P[n-2][1] + P[n-3][1],
            3*P[n-1][2] - 4*P[n-2][2] + P[n-3][2] ];
    } else {
      d = sub(P[Math.min(n-1, i+1)], P[Math.max(0, i-1)]);
    }
    for(k=2; norm(d) < 1e-12 && k < n; k++)         /* ponta colapsada (proa) */
      d = sub(P[Math.min(n-1, i+k)], P[Math.max(0, i-k)]);
    T[i] = unit(d);
  }
  return T;
}
function comprimento(P){
  var s = 0, i;
  for(i=1;i<P.length;i++) s += dist(P[i], P[i-1]);
  return s;
}
function emJ(P, j){
  var n = P.length;
  if(j <= 0) return P[0].slice();
  if(j >= n-1) return P[n-1].slice();
  var i = Math.floor(j), t = j - i;
  return lerp3(P[i], P[i+1], t);
}
function tanEmJ(T, j){
  var n = T.length;
  if(j <= 0) return T[0].slice();
  if(j >= n-1) return T[n-1].slice();
  var i = Math.floor(j), t = j - i;
  return unit(lerp3(T[i], T[i+1], t));
}

/* ------------------------------------------------------------- torcao ----- */
function torcao(A, tA, B, tB, minLen){
  var d = sub(B, A), L = norm(d);
  if(L < (minLen || 1e-9)) return null;
  var nA = cross(tA, d), nB = cross(tB, d);
  var la = norm(nA), lb = norm(nB);
  if(la < 1e-12 || lb < 1e-12) return null;
  var c = Math.max(-1, Math.min(1, dot(nA, nB)/(la*lb)));
  var s = dot(cross(nA, nB), unit(d))/(la*lb);
  return Math.atan2(s, c)*180/Math.PI;
}

/* Torcao das geratrizes de baliza (A[i] ligado a B[i]) — o regramento que o
   visualizador desenha e o primeiro que um projetista testaria. */
function torcaoBaliza(A, B, minLen){
  var tA = tangentes(A), tB = tangentes(B), out = [], i;
  for(i=0;i<A.length;i++) out.push(torcao(A[i], tA[i], B[i], tB[i], minLen));
  return out;
}
function resumo(v){
  var f = v.filter(function(x){ return x !== null && isFinite(x); }).map(Math.abs);
  if(!f.length) return { max:null, rms:null, n:0 };
  return { max: Math.max.apply(null, f),
           rms: Math.sqrt(f.reduce(function(s,x){ return s+x*x; }, 0)/f.length),
           n: f.length };
}

/* --------------------------------------------- melhor regramento possivel -- */
function melhorRegramento(A, B, opt){
  opt = opt || {};
  var minLen = opt.minLen || 0, tol = opt.tol === undefined ? 1e-3 : opt.tol;
  var tA = tangentes(A), tB = tangentes(B);
  var n = A.length, m = B.length;
  var pares = [], defeitos = [], jAnt = 0, i, j;

  for(i=0;i<n;i++){
    var f = [], validos = 0;
    for(j=0;j<m;j++){
      var w = torcao(A[i], tA[i], B[j], tB[j], minLen);
      f.push(w);
      if(w !== null) validos++;
    }
    if(validos === 0){ pares.push(null); defeitos.push(null); continue; }

    var raiz = null, jIni = Math.max(0, Math.floor(jAnt));
    /* raiz exatamente onde a busca comeca (caso comum na popa) */
    if(f[jIni] !== null && Math.abs(f[jIni]) <= tol) raiz = jIni;
    for(j=jIni;raiz === null && j+1<m;j++){
      var a = f[j], b = f[j+1];
      if(a === null || b === null) continue;
      if(a*b < 0){
        var lo = j, hi = j+1, k, mid, fm;
        for(k=0;k<44;k++){
          mid = (lo+hi)/2;
          fm = torcao(A[i], tA[i], emJ(B, mid), tanEmJ(tB, mid), minLen);
          if(fm === null) break;
          if(fm*a < 0) hi = mid; else lo = mid;
        }
        raiz = (lo+hi)/2;
      }
    }
    if(raiz !== null){ pares.push(raiz); defeitos.push(0); jAnt = raiz; }
    else {
      var best = Infinity, bj = null;
      for(j=jIni;j<m;j++) if(f[j] !== null && Math.abs(f[j]) < best){ best = Math.abs(f[j]); bj = j; }
      pares.push(bj); defeitos.push(best === Infinity ? null : best);
      if(bj !== null) jAnt = Math.max(jAnt, bj);
    }
  }
  var comDef = defeitos.filter(function(d){ return d !== null; });
  var semRaiz = comDef.filter(function(d){ return d > 1e-6; });
  return {
    pares: pares, defeitos: defeitos,
    defeitoMax: comDef.length ? Math.max.apply(null, comDef) : 0,
    defeitoRms: comDef.length ? Math.sqrt(comDef.reduce(function(s,d){ return s+d*d; },0)/comDef.length) : 0,
    fracaoSemRaiz: comDef.length ? semRaiz.length/comDef.length : 0
  };
}

/* ================================================= curvatura gaussiana ===== */
/* 2*pi menos a soma dos angulos das faces que chegam ao vertice interno.
   Somada sobre a chapa converge para a integral de |K| dA e nao depende do
   refino — ao contrario do erro por face, que vai a zero com o refino mesmo
   numa superficie que nao e desenvolvivel. */
function gauss(P){
  var nx = P.length - 1, ny = P[0].length - 1, i, j, k;
  var total = 0, maxV = 0, lista = [], ignorados = 0;
  function ang(o, p, q){
    var u = unit(sub(p, o)), v = unit(sub(q, o));
    return Math.acos(Math.max(-1, Math.min(1, dot(u, v))));
  }
  /* Escala tipica da malha. Onde as geratrizes convergem (a proa) os vertices
     ficam quase coincidentes e o defeito angular ali e ruido de arredondamento
     amplificado — numa malha 800x24 isso levava o total de 0,2 para 53 graus.
     O corte e explicito e o numero de vertices descartados volta junto. */
  var soma = 0, n = 0;
  for(i=0;i<nx;i++) for(j=0;j<=ny;j++){ soma += dist(P[i][j], P[i+1][j]); n++; }
  for(i=0;i<=nx;i++) for(j=0;j<ny;j++){ soma += dist(P[i][j], P[i][j+1]); n++; }
  var esc = n ? soma/n : 1, minA = 1e-3*esc;

  for(i=1;i<nx;i++) for(j=1;j<ny;j++){
    var o = P[i][j];
    /* leque na triangulacao pela diagonal (i+1,j)-(i,j+1) */
    var viz = [ P[i+1][j], P[i][j+1], P[i-1][j+1], P[i-1][j], P[i][j-1], P[i+1][j-1] ];
    var s = 0, degen = false;
    for(k=0;k<6;k++) if(dist(o, viz[k]) < minA){ degen = true; break; }
    if(degen){ ignorados++; continue; }
    for(k=0;k<6;k++) s += ang(o, viz[k], viz[(k+1)%6]);
    var K = 2*Math.PI - s;
    total += Math.abs(K);
    if(Math.abs(K) > maxV) maxV = Math.abs(K);
    lista.push({ i:i, j:j, K:K });
  }
  return { totalAbs: total*180/Math.PI, max: maxV*180/Math.PI, lista: lista,
           verticesIgnorados: ignorados };
}

/* Identidade de Gauss-Bonnet no disco triangulado: a soma dos defeitos
   angulares internos mais a dos externos do contorno da exatamente 2*pi.
   Serve de autoteste da contagem de angulos. */
function gaussBonnet(P){
  var nx = P.length - 1, ny = P[0].length - 1, i, j;
  function ang(o, p, q){
    var u = unit(sub(p, o)), v = unit(sub(q, o));
    return Math.acos(Math.max(-1, Math.min(1, dot(u, v))));
  }
  /* triangulos da malha */
  var T = [];
  for(i=0;i<nx;i++) for(j=0;j<ny;j++){
    T.push([[i,j],[i+1,j],[i,j+1]]);
    T.push([[i+1,j],[i+1,j+1],[i,j+1]]);
  }
  var somaAng = {};
  T.forEach(function(t){
    var A = P[t[0][0]][t[0][1]], B = P[t[1][0]][t[1][1]], C = P[t[2][0]][t[2][1]];
    var ks = [t[0].join(','), t[1].join(','), t[2].join(',')];
    var vs = [ang(A,B,C), ang(B,C,A), ang(C,A,B)];
    ks.forEach(function(k, n){ somaAng[k] = (somaAng[k] || 0) + vs[n]; });
  });
  var total = 0;
  for(i=0;i<=nx;i++) for(j=0;j<=ny;j++){
    var borda = (i === 0 || i === nx || j === 0 || j === ny);
    var s = somaAng[i + ',' + j] || 0;
    total += (borda ? Math.PI : 2*Math.PI) - s;
  }
  return total;                                       /* deve dar 2*pi */
}

/* ================================================== planificacao da chapa == */
function circulos(p, r1, q, r2){
  var dx = q[0]-p[0], dy = q[1]-p[1], d = Math.hypot(dx, dy);
  if(d < 1e-12) return null;
  var a = (r1*r1 - r2*r2 + d*d)/(2*d), h2 = r1*r1 - a*a;
  var h = h2 > 0 ? Math.sqrt(h2) : 0;
  var mx = p[0] + a*dx/d, my = p[1] + a*dy/d, ux = -dy/d, uy = dx/d;
  return [[mx + h*ux, my + h*uy], [mx - h*ux, my - h*uy]];
}
function crossZ(o, p, q){ return (p[0]-o[0])*(q[1]-o[1]) - (p[1]-o[1])*(q[0]-o[0]); }
/* Coloca o vertice que falta mantendo a orientacao do triangulo (a,b,c). */
function poeB(a, c, ra, rc){
  var s = circulos(a, ra, c, rc);
  if(!s) return [a[0] + ra, a[1]];
  return crossZ(a, s[0], c) > 0 ? s[0] : s[1];
}
function poeC(a, b, ra, rb){
  var s = circulos(a, ra, b, rb);
  if(!s) return [a[0], a[1] + ra];
  return crossZ(a, b, s[0]) > 0 ? s[0] : s[1];
}

/* Desdobra a malha triangulada face a face — isometrico em cada triangulo.
   Se a chapa for desenvolvivel isto ja e a planificacao exata; se nao for, as
   faces nao fecham e o erro fica acumulado numa borda, que o relaxamento
   depois reparte pela chapa inteira. */
function desdobraMalha(P){
  var nx = P.length - 1, ny = P[0].length - 1, i, j;
  var Q = [], D = dist;
  for(i=0;i<=nx;i++) Q.push(new Array(ny+1));
  Q[0][0] = [0, 0];
  Q[0][1] = [0, D(P[0][0], P[0][1])];
  if(nx >= 1){
    /* T1(0,0) = (0,0),(1,0),(0,1) — falta b */
    Q[1][0] = poeB(Q[0][0], Q[0][1], D(P[0][0], P[1][0]), D(P[0][1], P[1][0]));
    /* T2(0,0) = (1,0),(1,1),(0,1) — falta b */
    if(ny >= 1) Q[1][1] = poeB(Q[1][0], Q[0][1], D(P[1][0], P[1][1]), D(P[0][1], P[1][1]));
    for(j=2;j<=ny;j++){
      /* T1(0,j-1) = (0,j-1),(1,j-1),(0,j) — falta c */
      Q[0][j] = poeC(Q[0][j-1], Q[1][j-1], D(P[0][j-1], P[0][j]), D(P[1][j-1], P[0][j]));
      /* T2(0,j-1) = (1,j-1),(1,j),(0,j) — falta b */
      Q[1][j] = poeB(Q[1][j-1], Q[0][j], D(P[1][j-1], P[1][j]), D(P[0][j], P[1][j]));
    }
  }
  for(i=2;i<=nx;i++){
    /* T1(i-1,0) = (i-1,0),(i,0),(i-1,1) — falta b */
    Q[i][0] = poeB(Q[i-1][0], Q[i-1][1], D(P[i-1][0], P[i][0]), D(P[i-1][1], P[i][0]));
    for(j=1;j<=ny;j++)
      /* T2(i-1,j-1) = (i,j-1),(i,j),(i-1,j) — falta b */
      Q[i][j] = poeB(Q[i][j-1], Q[i-1][j], D(P[i][j-1], P[i][j]), D(P[i-1][j], P[i][j]));
  }
  return Q;
}

/* Arestas da triangulacao: horizontal, vertical e UMA diagonal por face. */
function arestas(P){
  var nx = P.length - 1, ny = P[0].length - 1, E = [], i, j;
  function push(i1,j1,i2,j2){ E.push([i1,j1,i2,j2, dist(P[i1][j1], P[i2][j2])]); }
  for(i=0;i<=nx;i++) for(j=0;j<=ny;j++){
    if(i<nx) push(i,j,i+1,j);
    if(j<ny) push(i,j,i,j+1);
    if(i<nx && j<ny) push(i+1,j,i,j+1);
  }
  return E;
}

/* Interpola as posicoes de uma malha grossa ja planificada sobre a fina. */
function sobeNivel(Qc, cx, cy, nx, ny){
  var Q = [], i, j;
  function ondeC(lista, idx){
    var a = 0;
    while(a+1 < lista.length && lista[a+1] <= idx) a++;
    if(a+1 >= lista.length) return [lista.length-1, 0];
    var t = (idx - lista[a])/(lista[a+1] - lista[a]);
    return [a, t];
  }
  for(i=0;i<=nx;i++){
    var li = ondeC(cx, i), Li = [];
    for(j=0;j<=ny;j++){
      var lj = ondeC(cy, j);
      var a = li[0], s = li[1], b = lj[0], t = lj[1];
      var a1 = Math.min(a+1, Qc.length-1), b1 = Math.min(b+1, Qc[0].length-1);
      var p00 = Qc[a][b], p10 = Qc[a1][b], p01 = Qc[a][b1], p11 = Qc[a1][b1];
      Li.push([ (1-s)*((1-t)*p00[0] + t*p01[0]) + s*((1-t)*p10[0] + t*p11[0]),
                (1-s)*((1-t)*p00[1] + t*p01[1]) + s*((1-t)*p10[1] + t*p11[1]) ]);
    }
    Q.push(Li);
  }
  return Q;
}

/* Planifica com multirresolucao: Gauss-Seidel sozinho leva O(n^2) varreduras
   para espalhar o residuo por uma chapa comprida. Resolvendo primeiro numa
   malha grossa e subindo de nivel, o modo longo ja chega resolvido e cada nivel
   so precisa de umas centenas de varreduras. */
/* Estatistica da deformacao. As arestas MUITO CURTAS ficam de fora do maximo:
   na ponta de proa as geratrizes convergem e as celulas caem para 5 mm, onde o
   erro RELATIVO estoura sem que a chapa tenha problema nenhum — 3,2 % numa
   aresta de 5 mm sao 0,16 mm. O corte e explicito e o numero de arestas
   descartadas volta junto, para o filtro nunca esconder nada em silencio. */
function residuo(Q, E, iFim){
  var maxDef = 0, somaQ = 0, maxAbs = 0, n = 0, k, soma = 0, nn = 0;
  var lim = (iFim === undefined || iFim === null) ? Infinity : iFim;
  for(k=0;k<E.length;k++){ if(E[k][4] > 1e-9){ soma += E[k][4]; nn++; } }
  var minL = nn ? 0.15*soma/nn : 0, fora = 0;
  for(k=0;k<E.length;k++){
    var t = E[k], L = t[4];
    if(L < 1e-9) continue;
    if(t[0] > lim || t[2] > lim) continue;      /* fora do trecho estatistico */
    if(L < minL){ fora++; continue; }
    var dd = d2(Q[t[0]][t[1]], Q[t[2]][t[3]]), rel = (dd - L)/L;
    if(Math.abs(rel) > maxDef) maxDef = Math.abs(rel);
    if(Math.abs(dd - L) > maxAbs) maxAbs = Math.abs(dd - L);
    somaQ += rel*rel; n++;
  }
  return { defMax: maxDef*100, defRms: n ? Math.sqrt(somaQ/n)*100 : 0, folgaMax: maxAbs,
           arestasCurtasIgnoradas: fora, arestasContadas: n };
}

function planificaMalha(P, iters, iFimStat){
  var nx = P.length - 1, ny = P[0].length - 1, i, j, k;
  var Q, E = arestas(P);

  /* Chapa desenvolvivel: o desdobramento guloso ja e a resposta EXATA, face a
     face. Relaxar em cima dela so introduz residuo — e foi o que aconteceu:
     um cilindro que saia com 1e-12 passou a sair com 4e-4 depois que a
     multirresolucao entrou. Entao confere antes e devolve. */
  var Qg = desdobraMalha(P), rg = residuo(Qg, E, iFimStat);
  if(rg.defMax < 1e-9)
    return { Q:Qg, defMax:rg.defMax, defRms:rg.defRms, folgaMax:rg.folgaMax,
             arestasCurtasIgnoradas:rg.arestasCurtasIgnoradas, contorno:contorno(Qg), exata:true };

  if(nx >= 16){
    var cx = [], cy = [];
    for(i=0;i<=nx;i+=2) cx.push(i);
    if(cx[cx.length-1] !== nx) cx.push(nx);
    if(ny >= 8){ for(j=0;j<=ny;j+=2) cy.push(j); if(cy[cy.length-1] !== ny) cy.push(ny); }
    else for(j=0;j<=ny;j++) cy.push(j);
    var Pc = cx.map(function(a){ return cy.map(function(b){ return P[a][b]; }); });
    Q = sobeNivel(planificaMalha(Pc, iters).Q, cx, cy, nx, ny);
  } else {
    Q = Qg;
  }
  var NV = (nx+1)*(ny+1);
  var id = function(a, b){ return a*(ny+1) + b; };

  /* lista de vizinhanca com o comprimento de repouso de cada aresta */
  var arMedE = 0, nE = 0;
  for(k=0;k<E.length;k++) if(E[k][4] > 1e-12){ arMedE += E[k][4]; nE++; }
  arMedE = nE ? arMedE/nE : 1;
  var viz = new Array(NV);
  for(i=0;i<NV;i++) viz[i] = [];
  for(k=0;k<E.length;k++){
    var t = E[k], u = id(t[0], t[1]), v = id(t[2], t[3]);
    /* Peso 1/L^2: a energia minimizada passa a ser a soma dos quadrados da
       DEFORMACAO RELATIVA, que e o que interessa a chapa. Com peso igual, uma
       malha de celulas desiguais troca de bom grado muita deformacao numa
       aresta curta por pouca numa longa.
       O PISO no comprimento e o que impede o exagero oposto: na ponta de proa,
       onde a tira fecha, as arestas caem para milimetros e 1/L^2 as tornaria
       mil vezes mais importantes que o resto da chapa — o solver passava a
       brigar por elas e o resultado saia com 8% de deformacao numa chapa que
       tem 0,3%. */
    var Lp = Math.max(t[4], 0.25*arMedE);
    var w = 1/(Lp*Lp);
    viz[u].push([v, t[4], w]); viz[v].push([u, t[4], w]);
  }
  /* posicoes num vetor plano, para o laco nao pagar indireção dupla */
  var X = new Float64Array(NV), Y = new Float64Array(NV);
  for(i=0;i<=nx;i++) for(j=0;j<=ny;j++){ X[id(i,j)] = Q[i][j][0]; Y[id(i,j)] = Q[i][j][1]; }

  /* Gauss-Seidel POR VERTICE com sobre-relaxamento.
     Projetar aresta por aresta — cada uma ate satisfazer exatamente — nao
     converge quando o sistema e infactivel, que e justamente o caso de uma
     chapa nao desenvolvivel: as projecoes ciclam e o residuo chega a CRESCER.
     Aqui cada vertice vai de uma vez para a posicao que minimiza a soma dos
     quadrados dos erros das suas arestas, que e descida de verdade. */
  var arMed = 0;
  for(k=0;k<E.length;k++) arMed += E[k][4];
  arMed = E.length ? arMed/E.length : 1;
  var tol = 1e-7*Math.max(1e-6, arMed);
  /* 4000 varreduras por nivel ja e o ponto fixo: subir para 20 mil nao mexe na
     quinta casa e custa cinco vezes mais. O que ainda muda o numero e o REFINO
     da malha, nao o numero de varreduras — malha grossa superestima a
     deformacao porque troca arco por corda. */
  var N = iters === undefined ? 4000 : iters, om = 1.85;
  /* Math.hypot em variavel local: dentro do laco mais quente cada leitura de
     `Math` e uma busca no objeto global, e isso sozinho respondia por boa parte
     do tempo. */
  var hyp = Math.hypot, abs = Math.abs;

  for(k=0;k<N;k++){
    var mov = 0;
    var ini = (k & 1) ? NV-1 : 0, fim = (k & 1) ? -1 : NV, passo = (k & 1) ? -1 : 1;
    for(var v=ini; v!==fim; v+=passo){
      var lst = viz[v], m = lst.length;
      if(!m) continue;
      var sx = 0, sy = 0, sw = 0, px = X[v], py = Y[v];
      for(var a=0;a<m;a++){
        var e = lst[a], q = e[0], L = e[1], wt = e[2];
        var dx = px - X[q], dy = py - Y[q], d = hyp(dx, dy);
        if(d < 1e-12){ sx += wt*(X[q] + L); sy += wt*Y[q]; }
        else { sx += wt*(X[q] + L*dx/d); sy += wt*(Y[q] + L*dy/d); }
        sw += wt;
      }
      var tx = sx/sw, ty = sy/sw;
      var ax = om*(tx - px), ay = om*(ty - py);
      X[v] = px + ax; Y[v] = py + ay;
      var mm = abs(ax) + abs(ay);
      if(mm > mov) mov = mm;
    }
    if(mov < tol) break;
  }
  for(i=0;i<=nx;i++) for(j=0;j<=ny;j++) Q[i][j] = [X[id(i,j)], Y[id(i,j)]];

  var rr = residuo(Q, E, iFimStat);
  if(rr.defRms > rg.defRms){ Q = Qg; rr = rg; }   /* nunca sair pior que o guloso */
  return { Q:Q, defMax:rr.defMax, defRms:rr.defRms, folgaMax:rr.folgaMax,
           arestasCurtasIgnoradas:rr.arestasCurtasIgnoradas, contorno:contorno(Q), exata:false };
}

/* Contorno fechado: borda j=0 de popa a proa, depois j=ny de volta. */
function contorno(Q){
  var nx = Q.length - 1, ny = Q[0].length - 1, out = [], i, j;
  for(i=0;i<=nx;i++)  out.push(Q[i][0]);          /* borda de baixo, popa->proa */
  for(j=1;j<=ny;j++)  out.push(Q[nx][j]);         /* topo de vante */
  for(i=nx-1;i>=0;i--) out.push(Q[i][ny]);        /* borda de cima, proa->popa */
  for(j=ny-1;j>=1;j--) out.push(Q[0][j]);         /* topo de re */
  return out;
}
function area2(pts){
  var s = 0, i, n = pts.length;
  for(i=0;i<n;i++){ var a = pts[i], b = pts[(i+1)%n]; s += a[0]*b[1] - b[0]*a[1]; }
  return Math.abs(s)/2;
}
/* Area 3D da malha, para comparar com a area da chapa planificada. */
function area3(P){
  var nx = P.length - 1, ny = P[0].length - 1, s = 0, i, j;
  function tri(A,B,C){ return norm(cross(sub(B,A), sub(C,A)))/2; }
  for(i=0;i<nx;i++) for(j=0;j<ny;j++){
    s += tri(P[i][j], P[i+1][j], P[i][j+1]);
    s += tri(P[i+1][j], P[i+1][j+1], P[i][j+1]);
  }
  return s;
}

/* ===== desenvolvivel.js ===== */
/* ============================================================================
   O painel desenvolvivel entre duas curvas de contorno.

   As geratrizes verdadeiras nao sao as de baliza: sao as de torcao nula, e elas
   correm INCLINADAS em relacao as balizas. Duas consequencias praticas:

   1. A geratriz que sai da quilha no espelho chega ao chine bem mais a vante, e
      sobra uma cunha junto ao espelho que geratriz nenhuma varre. A cunha se
      cobre com um trecho CONICO de apice no canto quilha-espelho, abrindo em
      leque ate a primeira geratriz de torcao nula — que e como se constroi
      casco desenvolvivel de verdade. O cone encosta no resto com o mesmo plano
      tangente, porque toda geratriz de cone e torsal e a primeira geratriz e
      comum as duas partes.

      (Prolongar a quilha pela tangente NAO resolve: o prolongamento e reto, e
      todas as geratrizes que saem dele convergem para o mesmo ponto do chine —
      o trecho vira um plano degenerado, com a malha colapsada.)

   2. Na proa sobra uma lasca simetrica, fechada do mesmo jeito com o leque ate
      o ponto de proa.
   ========================================================================== */


/* As tres arestas do casco quinado, amostradas em x. A quilha esta na linha de
   centro (y=0); chine e borda sao curvas no espaco. */
function arestasQuinado(hull, M){
  const K = [], Ch = [], S = [];
  for(let i=0;i<=M;i++){
    const x = hull.X0 + hull.LOA*i/M;
    const s = hull.section(x);
    const span = s.zs - s.zk;
    K.push([x, 0, s.zk]);
    Ch.push([x, s.Y[1], s.zk + span*s.U[1]]);
    S.push([x, s.ys, s.zs]);
  }
  return { K, C: Ch, S };
}

/* Painel desenvolvivel entre A e B, ja com os leques das duas pontas. */
function painel(A, B, opt){
  opt = opt || {};
  const minLen = opt.minLen || 25;
  const mr = melhorRegramento(A, B, { minLen });
  const nA = A.length, nB = B.length;

  /* corrida valida da correspondencia */
  let i0 = 0, i1 = nA - 1;
  while(i0 < nA && mr.pares[i0] === null) i0++;
  while(i1 >= 0 && mr.pares[i1] === null) i1--;
  if(i1 <= i0) throw new Error('nao ha regramento util neste painel');

  const ger = [];
  /* leque de re: apice em A[i0], abrindo de B[0] ate B[par[i0]] */
  const jIni = mr.pares[i0];
  if(jIni > 0.5){
    const passos = Math.max(2, Math.round(jIni));
    for(let k=0;k<passos;k++) ger.push([A[i0].slice(), emJ(B, jIni*k/passos)]);
  }
  /* corpo: geratrizes de torcao nula */
  for(let i=i0;i<=i1;i++){
    if(mr.pares[i] === null) continue;
    ger.push([A[i].slice(), emJ(B, mr.pares[i])]);
  }
  /* leque de vante: de A[i1..nA-1] ate B[nB-1] */
  const jFim = mr.pares[i1];
  if(i1 < nA-1 || jFim < nB-1-0.5){
    const passos = Math.max(2, nA-1-i1);
    for(let k=1;k<=passos;k++){
      const a = emJ(A, i1 + (nA-1-i1)*k/passos);
      const bj = jFim + (nB-1-jFim)*k/passos;
      ger.push([a, emJ(B, bj)]);
    }
  }

  const R = ger.length;
  const Aarr = ger.map(g => g[0]), Barr = ger.map(g => g[1]);

  function ponto(s, t){ return lerp3(emJ(Aarr, s), emJ(Barr, s), t); }
  function xEm(s, t){
    const a = emJ(Aarr, s), b = emJ(Barr, s);
    return a[0] + (b[0] - a[0])*t;
  }
  /* x(s,t) e nao-decrescente em s: combinacao convexa de duas nao-decrescentes. */
  function sPara(x, t){
    let lo = 0, hi = R-1;
    if(xEm(lo, t) >= x) return lo;
    if(xEm(hi, t) <= x) return hi;
    for(let k=0;k<60;k++){ const m = (lo+hi)/2; if(xEm(m, t) < x) lo = m; else hi = m; }
    return (lo+hi)/2;
  }
  /* Secao do painel no plano X = x, do lado A para o lado B, com n+1 pontos. */
  function secao(x, n){
    const out = [];
    for(let k=0;k<=n;k++){ const t = k/n; out.push(ponto(sPara(x, t), t)); }
    return out;
  }
  function cobertura(nt){
    let xMin = -Infinity, xMax = Infinity;
    for(let k=0;k<=nt;k++){
      const t = k/nt;
      xMin = Math.max(xMin, xEm(0, t));
      xMax = Math.min(xMax, xEm(R-1, t));
    }
    return { xMin, xMax };
  }
  /* Quantas geratrizes vieram de cada parte — util para relatar. */
  const nCone = jIni > 0.5 ? Math.max(2, Math.round(jIni)) : 0;
  return { ger, R, nCone, ponto, xEm, secao, sPara, cobertura, mr, i0, i1 };
}

/* Malha do painel entre dois x, para planificar. */
function malhaPainel(pn, x0, x1, nx, ny){
  const P = [];
  for(let i=0;i<=nx;i++){
    const x = x0 + (x1-x0)*i/nx, linha = [];
    for(let j=0;j<=ny;j++){ const t = j/ny; linha.push(pn.ponto(pn.sPara(x, t), t)); }
    P.push(linha);
  }
  return P;
}

/* Onde a geratriz ja e curta demais para a malha significar alguma coisa. Na
   ponta de proa as geratrizes convergem para um ponto: o vertice de la carrega
   sozinho um defeito angular enorme (51 dos 53 graus de uma malha 800x24) que
   e artefato do colapso, nao curvatura da chapa. A estatistica sai do trecho
   util; a lasca fica de fora e e relatada a parte. */
function intervaloUtil(pn, frac){
  const f = frac === undefined ? 0.05 : frac;
  let mx = 0;
  for(const g of pn.ger) mx = Math.max(mx, dist(g[0], g[1]));
  const lim = f*mx;
  /* comeca depois do leque de re: la todas as geratrizes saem do MESMO ponto,
     e a coluna de vertices coincidentes envenena o defeito angular. Cone e
     desenvolvivel por definicao — nao precisa de numero para provar. */
  let i0 = Math.max(0, pn.nCone), i1 = pn.R - 1;
  while(i0 < i1 && dist(pn.ger[i0][0], pn.ger[i0][1]) < lim) i0++;
  while(i1 > i0 && dist(pn.ger[i1][0], pn.ger[i1][1]) < lim) i1--;
  return [i0, i1];
}

/* Malha seguindo as PROPRIAS geratrizes (nao aparada por baliza). E a chapa
   verdadeira: cada linha da malha e uma geratriz inteira. */
function malhaGeratriz(pn, ny, i0, i1){
  const P = [];
  const a = i0 === undefined ? 0 : i0, b = i1 === undefined ? pn.R-1 : i1;
  for(let i=a;i<=b;i++){
    const linha = [];
    for(let j=0;j<=ny;j++) linha.push(lerp3(pn.ger[i][0], pn.ger[i][1], j/ny));
    P.push(linha);
  }
  return P;
}

/* ===== diagonais.js ===== */
/* ============================================================================
   Diagonais e tiras desenvolviveis num casco de bojo redondo.

   Uma diagonal, no plano de balizas, e uma RETA inclinada: em tres dimensoes,
   um plano  a*y + b*z = c  que corre o comprimento todo. A curva que ela marca
   no casco e a interseccao desse plano com a superficie.

   Com N-1 diagonais entre a quilha e a borda o casco fica dividido em N tiras.
   Cada tira e entao regrada pelas geratrizes de torcao nula entre as suas duas
   costuras — e a partir dai vale exatamente a mesma maquina do casco quinado.

   O que isso significa na pratica: cortar um casco redondo em tiras e regrar
   cada uma e o mesmo que CONSTRUI-LO COMO CASCO DE N QUINAS. A corda que a
   geratriz tira entre duas costuras corta por dentro do bojo, e a flecha vale
   mais ou menos w^2/(8R) — cai com o QUADRADO da largura da tira. E por isso
   que dobrar o numero de tiras divide o desvio por quatro, e e isso que a
   hidrostatica antes/depois mede.

   Onde por as diagonais: cada uma persegue uma linha de PERIMETRO RELATIVO
   constante — a linha que divide todas as balizas na mesma proporcao, e que
   daria tiras de largura pareja. Como essa linha nao e reta no plano de
   balizas, a diagonal e a reta que melhor a aproxima, por minimos quadrados
   ortogonais com peso na area de cada baliza (senao as balizas minusculas da
   proa mandariam no ajuste tanto quanto a mestra).
   ========================================================================== */


const NP_BAL = 160;                         /* pontos por meia-baliza na analise */

/* Perimetro acumulado e ponto a um perimetro relativo dado. */
function perfil(hull, x, np){
  const poly = halfPoly(hull.section(x), np || NP_BAL);
  const s = [0];
  for(let i=1;i<poly.length;i++)
    s.push(s[i-1] + Math.hypot(poly[i][0]-poly[i-1][0], poly[i][1]-poly[i-1][1]));
  return { poly, s, total: s[s.length-1] };
}
function pontoEmG(pf, g){
  const alvo = g*pf.total;
  if(pf.total < 1e-9) return pf.poly[0].slice();
  for(let i=1;i<pf.s.length;i++){
    if(pf.s[i] >= alvo - 1e-12){
      const t = (alvo - pf.s[i-1])/Math.max(1e-12, pf.s[i]-pf.s[i-1]);
      return [ pf.poly[i-1][0] + (pf.poly[i][0]-pf.poly[i-1][0])*t,
               pf.poly[i-1][1] + (pf.poly[i][1]-pf.poly[i-1][1])*t ];
    }
  }
  return pf.poly[pf.poly.length-1].slice();
}

/* Ajuste ortogonal de reta a pontos (y,z) com pesos: devolve normal unitaria
   (a,b) e offset c com a*y + b*z = c. */
function retaPorPCA(pts, pesos){
  let W = 0, my = 0, mz = 0, i;
  for(i=0;i<pts.length;i++){ const w = pesos[i]; W += w; my += w*pts[i][0]; mz += w*pts[i][1]; }
  if(W < 1e-12) return null;
  my /= W; mz /= W;
  let syy = 0, szz = 0, syz = 0;
  for(i=0;i<pts.length;i++){
    const w = pesos[i], dy = pts[i][0]-my, dz = pts[i][1]-mz;
    syy += w*dy*dy; szz += w*dz*dz; syz += w*dy*dz;
  }
  /* menor autovetor da matriz de covariancia = normal da reta */
  const tr = syy + szz, det = syy*szz - syz*syz;
  const disc = Math.sqrt(Math.max(0, tr*tr/4 - det));
  const lmin = tr/2 - disc;
  let a, b;
  if(Math.abs(syz) > 1e-12){ a = lmin - szz; b = syz; }
  else { if(syy <= szz){ a = 1; b = 0; } else { a = 0; b = 1; } }
  const n = Math.hypot(a, b);
  a /= n; b /= n;
  if(b < 0){ a = -a; b = -b; }            /* orienta com componente z positiva */
  return { a, b, c: a*my + b*mz };
}

/* Densidade de curvatura gaussiana ao longo do perimetro da baliza: quanto de
   |K| dA o casco tem em cada faixa de perimetro relativo. E o mapa da
   dificuldade — onde ela se concentra, a chapa precisa ser mais estreita. */
function densidadeK(hull, ng, M){
  ng = ng || 24; M = M || 80;
  const P = [];
  for(let i=0;i<=M;i++){
    const x = hull.X0 + hull.LOA*i/M;
    const pf = perfil(hull, x, 200), linha = [];
    for(let j=0;j<=ng;j++){
      const p = pf.total > 1e-6 ? pontoEmG(pf, j/ng) : pf.poly[0];
      linha.push([x, p[0], p[1]]);
    }
    P.push(linha);
  }
  const g = gauss(P);
  const dens = new Array(ng).fill(0);
  for(const v of g.lista) dens[Math.min(ng-1, v.j)] += Math.abs(v.K);
  /* suaviza: a densidade e usada so para repartir, e ruido de celula viraria
     costura torta */
  const suave = dens.map((_, j) => {
    let s = 0, n = 0;
    for(let k=Math.max(0,j-1);k<=Math.min(ng-1,j+1);k++){ s += dens[k]; n++; }
    return s/n;
  });
  return suave;
}

/* Onde cortar o perimetro: N faixas com a MESMA integral de |K|, com um piso de
   largura para nenhuma tira virar um fio. Repartir por perimetro igual da
   chapas de largura pareja mas dificuldade muito desigual — a tira da quilha
   (o garboard) fica com quase toda a curvatura do casco. */
function fracoesPorK(hull, N, pisoRel){
  const ng = 24, dens = densidadeK(hull, ng);
  const total = dens.reduce((a, b) => a + b, 0);
  if(total < 1e-9) return Array.from({length:N+1}, (_, k) => k/N);
  const piso = (pisoRel === undefined ? 0.45 : pisoRel)/N;   /* largura minima */
  /* mistura a repartição por curvatura com a por perimetro, para respeitar o piso */
  const acum = [0];
  for(let j=0;j<ng;j++) acum.push(acum[j] + dens[j]/total);
  const fr = [0];
  for(let k=1;k<N;k++){
    const alvo = k/N;
    let j = 0;
    while(j < ng && acum[j+1] < alvo) j++;
    const t = (alvo - acum[j])/Math.max(1e-12, acum[j+1]-acum[j]);
    fr.push((j + t)/ng);
  }
  fr.push(1);
  /* aplica o piso empurrando para a direita e depois normalizando */
  for(let k=1;k<=N;k++) if(fr[k] < fr[k-1] + piso) fr[k] = fr[k-1] + piso;
  const esc = 1/fr[N];
  return fr.map(v => v*esc);
}

/* As N-1 diagonais de um casco, mais os extremos quilha e borda. */
function diagonais(hull, N, opt){
  opt = opt || {};
  const M = opt.M || 120;
  const fr = opt.fracoes || Array.from({length:N+1}, (_, k) => k/N);
  const xs = [], pfs = [], pesos = [];
  for(let i=0;i<=M;i++){
    const x = hull.X0 + hull.LOA*i/M;
    const pf = perfil(hull, x, opt.np || NP_BAL);
    xs.push(x); pfs.push(pf);
    pesos.push(pf.total);                  /* baliza minuscula pesa pouco */
  }
  const planos = [];
  for(let k=1;k<N;k++){
    const g = fr[k], pts = [], w = [];
    for(let i=0;i<=M;i++){
      if(pfs[i].total < 1e-6) continue;
      pts.push(pontoEmG(pfs[i], g)); w.push(pesos[i]);
    }
    planos.push(retaPorPCA(pts, w));
  }
  return planos;
}

/* Onde o plano (a,b,c) corta a baliza: devolve o perimetro relativo do cruzamento.
   f = a*y + b*z - c cresce monotonicamente ao longo da baliza nos casos de
   interesse; se nao cruzar, devolve null. */
function cruzaBaliza(pf, plano){
  const f = p => plano.a*p[0] + plano.b*p[1] - plano.c;
  const n = pf.poly.length;
  const fk = f(pf.poly[0]), fb = f(pf.poly[n-1]);
  /* Baliza inteira de um lado do plano: a diagonal ja passou dela. Acontece na
     proa, onde a baliza fecha na roda e vira um segmento vertical curto. A
     costura ENCOSTA no extremo — a tira morre ali, como um trecho de chapa que
     se esgota na roda. Antes o fallback jogava a costura num perimetro relativo
     arbitrario e criava um bico, e o bico sozinho respondia por 100 dos 105
     graus de curvatura gaussiana de uma tira. */
  if(fk >= 0 && fb >= 0) return { g: 0, p: pf.poly[0].slice(), esgotada: -1 };
  if(fk <= 0 && fb <= 0) return { g: 1, p: pf.poly[n-1].slice(), esgotada: 1 };
  let f0 = fk;
  for(let i=1;i<n;i++){
    const f1 = f(pf.poly[i]);
    if(f0 === 0) return { g: pf.s[i-1]/pf.total, p: pf.poly[i-1].slice() };
    if(f0*f1 < 0){
      const t = f0/(f0 - f1);
      const p = [ pf.poly[i-1][0] + (pf.poly[i][0]-pf.poly[i-1][0])*t,
                  pf.poly[i-1][1] + (pf.poly[i][1]-pf.poly[i-1][1])*t ];
      const s = pf.s[i-1] + (pf.s[i]-pf.s[i-1])*t;
      return { g: pf.total > 1e-9 ? s/pf.total : 0, p };
    }
    f0 = f1;
  }
  return { g: 1, p: pf.poly[n-1].slice(), esgotada: 1 };
}

/* As N+1 curvas de contorno das tiras: quilha, as N-1 diagonais, e a borda.
   Todas amostradas nos mesmos x, para as tiras casarem. */
function contornos(hull, N, M, opt){
  opt = opt || {};
  const planos = opt.planos || diagonais(hull, N, opt);
  const curvas = [];
  for(let k=0;k<=N;k++) curvas.push([]);
  const relat = [];
  for(let i=0;i<=M;i++){
    const x = hull.X0 + hull.LOA*i/M;
    const pf = perfil(hull, x, opt.np || NP_BAL);
    curvas[0].push([x, pf.poly[0][0], pf.poly[0][1]]);                     /* quilha */
    const linha = [0];
    for(let k=1;k<N;k++){
      const cr = cruzaBaliza(pf, planos[k-1]);
      linha.push(cr.g);
      curvas[k].push([x, cr.p[0], cr.p[1]]);
    }
    linha.push(1);
    relat.push(linha);
    curvas[N].push([x, pf.poly[pf.poly.length-1][0], pf.poly[pf.poly.length-1][1]]);  /* borda */
  }
  return { curvas, planos, relat };
}

/* ===== redondo-tiras.js ===== */
/* ============================================================================
   O casco redondo cortado em N tiras por diagonais.

   Cada tira e regrada por baliza: a corda reta que liga as duas costuras. Isso
   e, exatamente, CONSTRUIR O CASCO COMO CASCO DE N QUINAS — e e o que permite
   plainar a chapa, porque a corda tira da tira a curvatura transversal que
   nenhuma chapa plana aceita.

   O preco e a flecha: a corda corta por dentro do bojo, e o casco construido
   desloca menos que o desenhado. A flecha vale mais ou menos w^2/(8R), entao
   cai com o quadrado da largura da tira — e e por isso que o numero de tiras e
   uma decisao de projeto, nao um detalhe.
   ========================================================================== */



/* Casco multiquinado: a baliza vira a poligonal pelos N+1 pontos de costura. */
function cascoEmTiras(hull, N, opt){
  opt = opt || {};
  const np = opt.np || 240;
  const planos = opt.planos || diagonais(hull, N, { M: opt.Mfit || 120, np, fracoes: opt.fracoes });

  const cache = new Map();
  function costuras(x){
    const k = Math.round(x*100);
    if(cache.has(k)) return cache.get(k);
    const pf = perfil(hull, x, np);
    const pts = [ pf.poly[0].slice() ];
    for(let j=0;j<N-1;j++) pts.push(cruzaBaliza(pf, planos[j]).p);
    pts.push(pf.poly[pf.poly.length-1].slice());
    cache.set(k, pts);
    return pts;
  }
  /* Poligonal da meia-baliza com n+1 pontos, seguindo as cordas entre costuras. */
  function polyEm(x, n){
    const pts = costuras(x);
    /* comprimento acumulado sobre a poligonal de costuras */
    const s = [0];
    for(let i=1;i<pts.length;i++) s.push(s[i-1] + Math.hypot(pts[i][0]-pts[i-1][0], pts[i][1]-pts[i-1][1]));
    const tot = s[s.length-1];
    const out = [];
    if(tot < 1e-9){ for(let i=0;i<=n;i++) out.push(pts[0].slice()); return out; }
    for(let i=0;i<=n;i++){
      const alvo = tot*i/n;
      let j = 1;
      while(j < s.length-1 && s[j] < alvo) j++;
      const t = (alvo - s[j-1])/Math.max(1e-12, s[j]-s[j-1]);
      out.push([ pts[j-1][0] + (pts[j][0]-pts[j-1][0])*t,
                 pts[j-1][1] + (pts[j][1]-pts[j-1][1])*t ]);
    }
    /* z monotono, exigencia do integrador da hidrostatica */
    for(let i=1;i<out.length;i++) if(out[i][1] < out[i-1][1]) out[i][1] = out[i-1][1];
    return out;
  }

  const dev = {
    rows: hull.rows, mode: hull.mode, nMid: hull.nMid,
    X0: hull.X0, LOA: hull.LOA, stations: hull.stations,
    clampCount: hull.clampCount, planos, N,
    costuras,
    section: function(x){
      const base = hull.section(x);
      const poly = polyEm(x, 60);
      return { zk: poly[0][1], zs: poly[poly.length-1][1], ys: poly[poly.length-1][0],
               U: base.U, Y: base.Y, mode: base.mode, p: base.p, pRms: base.pRms,
               superFits: base.superFits, pronta: poly };
    },
    bounds: function(){
      let maxY = 0, minZ = Infinity, maxZ = -Infinity;
      for(let i=0;i<=400;i++){
        const s = dev.section(hull.X0 + hull.LOA*i/400);
        for(const p of s.pronta) if(p[0] > maxY) maxY = p[0];
        if(s.zk < minZ) minZ = s.zk;
        if(s.zs > maxZ) maxZ = s.zs;
      }
      return { maxY, minZ, maxZ };
    }
  };
  return dev;
}

/* ===== quinado-desenv.js ===== */
/* ============================================================================
   O casco quinado regrado pelas geratrizes verdadeiras.

   As curvas de contorno — quilha, chine e borda — nao mudam nem um milimetro.
   O que muda e a superficie ENTRE elas: em vez de interpolar por baliza (reta
   de x constante), ela passa a ser gerada pelas geratrizes de torcao nula, que
   correm inclinadas. E a mesma forma que uma chapa plana assume quando se
   dobra: a diferenca entre as duas superficies e o que a hidrostatica antes/
   depois mede.
   ========================================================================== */



const NSEC = 40;                        /* pontos por painel na baliza */

function cascoDesenvolvivel(hull, M){
  const A = arestasQuinado(hull, M || 500);
  const pFundo   = painel(A.K, A.C);
  const pCostado = painel(A.C, A.S);

  const cache = new Map();
  function secaoXY(x){
    const k = Math.round(x*100);
    if(cache.has(k)) return cache.get(k);
    const s1 = pFundo.secao(x, NSEC);            /* quilha -> chine */
    const s2 = pCostado.secao(x, NSEC);          /* chine  -> borda */
    const poly = [];
    for(let i=0;i<=NSEC;i++)  poly.push([s1[i][1], s1[i][2]]);
    for(let i=1;i<=NSEC;i++)  poly.push([s2[i][1], s2[i][2]]);
    /* z tem de crescer ao longo da poligonal: e o que torna exata a integral de
       y dz na hidrostatica. A superficie desenvolvivel e monotona no casco
       inteiro, mas um empate numerico na ponta viraria divisao por zero. */
    for(let i=1;i<poly.length;i++)
      if(poly[i][1] < poly[i-1][1]) poly[i][1] = poly[i-1][1];
    cache.set(k, poly);
    return poly;
  }

  const dev = {
    rows: hull.rows, mode: hull.mode, nMid: hull.nMid,
    X0: hull.X0, LOA: hull.LOA, stations: hull.stations,
    clampCount: hull.clampCount,
    painel: { fundo: pFundo, costado: pCostado },
    section: function(x){
      const base = hull.section(x);
      const poly = secaoXY(x);
      return { zk: poly[0][1], zs: poly[poly.length-1][1], ys: poly[poly.length-1][0],
               U: base.U, Y: base.Y, mode: base.mode, p: base.p, pRms: base.pRms,
               superFits: base.superFits, pronta: poly };
    },
    bounds: function(){
      let maxY = 0, minZ = Infinity, maxZ = -Infinity;
      for(let i=0;i<=400;i++){
        const s = dev.section(hull.X0 + hull.LOA*i/400);
        for(const p of s.pronta){ if(p[0] > maxY) maxY = p[0]; }
        if(s.zk < minZ) minZ = s.zk;
        if(s.zs > maxZ) maxZ = s.zs;
      }
      return { maxY, minZ, maxZ };
    }
  };
  return dev;
}

/* ===== chapas.js ===== */
/* ============================================================================
   Montagem das chapas e dos gabaritos de baliza.

   Vive fora da interface de propósito: o mesmo código roda no navegador e no
   Node, então o que os testes medem é exatamente o que a página mostra e o que
   o PDF imprime.
   ========================================================================== */






var NX_CH = 80, NY_CH = 5;          /* malha de cada chapa */
var SWEEPS = 1500;                  /* varreduras do relaxamento por nível */

/* Roda a chapa para o eixo maior ficar deitado e a proa para a direita. */
function orienta(Q){
  var pts = [], i, j;
  for(i=0;i<Q.length;i++) for(j=0;j<Q[i].length;j++) pts.push(Q[i][j]);
  var n = pts.length, mx = 0, my = 0;
  for(i=0;i<n;i++){ mx += pts[i][0]; my += pts[i][1]; }
  mx /= n; my /= n;
  var sxx = 0, syy = 0, sxy = 0;
  for(i=0;i<n;i++){
    var dx = pts[i][0]-mx, dy = pts[i][1]-my;
    sxx += dx*dx; syy += dy*dy; sxy += dx*dy;
  }
  var th = 0.5*Math.atan2(2*sxy, sxx - syy);      /* eixo principal */
  var c = Math.cos(-th), s = Math.sin(-th);
  function tr(p){
    var dx = p[0]-mx, dy = p[1]-my;
    return [dx*c - dy*s, dx*s + dy*c];
  }
  var a0 = tr(Q[0][0]), a1 = tr(Q[Q.length-1][0]);
  var vira = a1[0] < a0[0];                        /* proa para a direita */
  var R = [], x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
  for(i=0;i<Q.length;i++){
    var L = [];
    for(j=0;j<Q[i].length;j++){
      var p = tr(Q[i][j]);
      if(vira) p = [-p[0], -p[1]];
      L.push(p);
      if(p[0] < x0) x0 = p[0];
      if(p[0] > x1) x1 = p[0];
      if(p[1] < y0) y0 = p[1];
      if(p[1] > y1) y1 = p[1];
    }
    R.push(L);
  }
  for(i=0;i<R.length;i++) for(j=0;j<R[i].length;j++)
    R[i][j] = [R[i][j][0] - x0, R[i][j][1] - y0];
  return { Q: R, larg: x1-x0, alt: y1-y0 };
}

/* ---------------------------------------------------- as chapas, em 3D ---- */
function montaChapas(hullBase, modo, ntiras){
  var chapas = [], segs = [], i, j, k, hullDep = null, desenv = null, planos = null;

  if(modo === 'quinado'){
    var M = 300;
    var A = arestasQuinado(hullBase, M);
    var defs = [ { nome:'Fundo', sub:'quilha - chine', A:A.K, B:A.C },
                 { nome:'Costado', sub:'chine - borda', A:A.C, B:A.S } ];
    var pns = [];
    for(k=0;k<defs.length;k++){
      var pn = painel(defs[k].A, defs[k].B);
      pns.push(pn);
      var iTip = pn.R - 1;
      while(iTip > 3 && dist(pn.ger[iTip][0], pn.ger[iTip][1]) < 1) iTip--;
      var passo = Math.max(1, Math.floor(iTip/NX_CH));
      var P = [];
      for(i=0;i<=iTip;i+=passo){
        var L = [];
        for(j=0;j<=NY_CH;j++) L.push(lerp3(pn.ger[i][0], pn.ger[i][1], j/NY_CH));
        P.push(L);
      }
      if(P.length < 4) continue;
      chapas.push({ nome:defs[k].nome, sub:defs[k].sub, P:P, pronta:false });
      for(i=0;i<pn.R;i+=Math.max(1, Math.round(pn.R/34))) segs.push(pn.ger[i]);
    }
    hullDep = cascoDesenvolvivel(hullBase, M);
    desenv = vereditoQuinado(A, pns);
  } else {
    var M2 = 160;
    var ct = contornos(hullBase, ntiras, M2, { np:200 });
    hullDep = cascoEmTiras(hullBase, ntiras, { np:200, planos: ct.planos });
    planos = ct.planos;
    var iFim = Math.round(M2*0.94);            /* fora a lasca da roda */
    var passo2 = Math.max(1, Math.floor(M2/NX_CH));
    for(k=0;k<ntiras;k++){
      var Ca = ct.curvas[k], Cb = ct.curvas[k+1], P2 = [];
      for(i=0;i<=M2;i+=passo2){
        var L2 = [];
        for(j=0;j<=NY_CH;j++) L2.push(lerp3(Ca[i], Cb[i], j/NY_CH));
        P2.push(L2);
      }
      chapas.push({ nome:'Tira ' + (k+1),
        sub: k===0 ? 'quilha - d1'
           : (k === ntiras-1 ? 'd' + (ntiras-1) + ' - borda' : 'd' + k + ' - d' + (k+1)),
        P:P2, iFim:Math.floor(iFim/passo2), pronta:false });
    }
    for(k=1;k<ntiras;k++){
      var cv = ct.curvas[k];
      for(i=0;i+1<cv.length;i++) segs.push([cv[i], cv[i+1]]);
    }
    desenv = vereditoRedondo(hullBase);
  }
  return { chapas: chapas, hullDep: hullDep, segs: segs, desenv: desenv, planos: planos };
}

/* Planifica uma chapa e mede. Uma planificação só, com a estatística recortada
   no trecho útil — a lasca da roda fica de fora do número, não do desenho. */
function calculaChapa(ch, sweeps){
  var iFim = (ch.iFim && ch.iFim < ch.P.length-1) ? ch.iFim : null;
  var pl = planificaMalha(ch.P, sweeps === undefined ? SWEEPS : sweeps, iFim);
  var o = orienta(pl.Q);
  ch.Q = o.Q; ch.larg = o.larg; ch.alt = o.alt;
  ch.defMax = pl.defMax; ch.defRms = pl.defRms;
  ch.area3 = area3(ch.P); ch.area2 = area2(contorno(pl.Q));
  ch.k = gauss(iFim ? ch.P.slice(0, iFim+1) : ch.P).totalAbs;
  var lm = 0, ny = ch.Q[0].length - 1, q;
  for(q=0;q<ch.Q.length;q++) lm = Math.max(lm, d2(ch.Q[q][0], ch.Q[q][ny]));
  ch.vao = lm;
  ch.pronta = true;
  return ch;
}

/* ------------------------------------------------------------- veredito --- */
function vereditoQuinado(A, pns){
  var itens = [], nomes = ['Fundo', 'Costado'], pares = [[A.K, A.C], [A.C, A.S]], k, i, j;
  for(k=0;k<pns.length;k++){
    var tb = resumo(torcaoBaliza(pares[k][0], pares[k][1], 25));
    var iv = intervaloUtil(pns[k]);
    var Pd = malhaGeratriz(pns[k], 8, iv[0], iv[1]);
    var Pb = [];
    for(i=0;i<pares[k][0].length;i++){
      var L = [];
      for(j=0;j<=8;j++) L.push(lerp3(pares[k][0][i], pares[k][1][i], j/8));
      Pb.push(L);
    }
    itens.push({ nome:nomes[k], torcaoMax:tb.max, torcaoRms:tb.rms,
                 kAntes:gauss(Pb).totalAbs, kDepois:gauss(Pd).totalAbs,
                 cone:pns[k].nCone, ger:pns[k].R });
  }
  return { itens: itens };
}
function vereditoRedondo(h){
  var P = [], i, j, M = 120;
  for(i=0;i<=M;i++){
    var x = h.X0 + h.LOA*i/M, hp = halfPoly(h.section(x), 40), L = [];
    for(j=0;j<hp.length;j++) L.push([x, hp[j][0], hp[j][1]]);
    P.push(L);
  }
  return { kInteiro: gauss(P).totalAbs };
}

/* ------------------------------------------- gabaritos das balizas -------- */
/* A baliza já é plana: planificá-la é desenhá-la em verdadeira grandeza. Sai o
   gabarito do cavername, com as marcas das costuras onde a chapa encosta. */
function balizasDe(hullDep, modo, planos, calado, zBase, np){
  var out = [], i, k;
  var xs = hullDep.stations;
  for(i=0;i<xs.length;i++){
    var x = xs[i];
    var meia = halfPolyCut(hullDep.section(x), np || 120, x);
    if(!meia || meia.length < 3) continue;
    var largura = 0;
    for(k=0;k<meia.length;k++) if(meia[k][0] > largura) largura = meia[k][0];
    if(largura < 1) continue;                       /* baliza fechada na roda */
    var costuras = null;
    if(modo === 'redondo' && hullDep.costuras) costuras = hullDep.costuras(x).slice(1, -1);
    else if(modo === 'quinado'){
      var pr = hullDep.section(x).pronta;
      if(pr) costuras = [ pr[Math.floor(pr.length/2)] ];
    }
    out.push({ nome:'Baliza ' + (i+1), x:x, meia:meia, costuras:costuras });
  }
  return out;
}

/* ===== desenhos.js ===== */
/* ============================================================================
   Modelo comum dos desenhos planificados.

   A tela e o PDF consomem esta MESMA estrutura. Se cada um montasse o seu
   desenho, um dia divergiriam e o papel deixaria de ser o que está na tela —
   que é justamente o erro que arruína uma folha de traçado.

   Um desenho é sempre plano e em milímetros, com a origem no canto inferior
   esquerdo da sua própria caixa:

     { nome, sub, larg, alt,
       contorno: { pts:[[x,y],…], fechado:bool },
       linhas:   [ { pts:[[x,y],…], tipo:'geratriz'|'baliza'|'eixo'|'agua' } ],
       cotas:    [ { x, y, txt } ] }

   Tipos de linha, e por que cada um existe no papel:
     geratriz — onde a chapa dobra; serve para conferir o sentido da curvatura
     baliza   — onde cada baliza da tabela cruza a chapa; é por elas que a
                chapa se posiciona no cavername
     eixo     — linha de centro e linha de base da baliza
     agua     — a linha d'água do calado escolhido
   ========================================================================== */

/* -------------------------------------------------- módulo do quadriculado --
   O quadrado tem de ser um número redondo em milímetros (senão não se conta a
   mão) e ficar legível na escala do desenho. */
var MODULOS = [5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000];
function moduloMalha(esc, alvoPx){
  var alvo = alvoPx || 26, i;
  for(i=0;i<MODULOS.length;i++) if(MODULOS[i]*esc >= alvo) return MODULOS[i];
  return MODULOS[MODULOS.length-1];
}

/* ------------------------------------------------------------- a chapa ---- */
/* Q é a malha já planificada e orientada; P é a mesma malha em 3D, usada só
   para saber onde cada baliza da tabela cruza a chapa. */
function desenhoChapa(ch, estacoes){
  var Q = ch.Q, P = ch.P, ny = Q[0].length - 1, i, j;
  var linhas = [];

  /* geratrizes: uma a cada tantas, para o desenho não virar hachura */
  var passo = Math.max(1, Math.round(Q.length/26));
  for(i=0;i<Q.length;i+=passo)
    linhas.push({ pts: [Q[i][0].slice(), Q[i][ny].slice()], tipo: 'geratriz' });

  /* balizas da tabela */
  for(i=0;i<estacoes.length;i++){
    var mk = cruzaChapa(P, Q, estacoes[i]);
    if(mk) linhas.push({ pts: mk, tipo: 'baliza', rot: 'B' + (i+1) });
  }
  return {
    nome: ch.nome, sub: ch.sub, larg: ch.larg, alt: ch.alt,
    contorno: { pts: contornoMalha(Q), fechado: true },
    linhas: linhas,
    info: [ 'chapa ' + (ch.larg/1000).toFixed(3) + ' x ' + (ch.alt/1000).toFixed(3) + ' m',
            'vao max ' + Math.round(ch.vao) + ' mm',
            'area ' + (ch.area2/1e6).toFixed(3) + ' m2' ]
  };
}
function contornoMalha(Q){
  var nx = Q.length - 1, ny = Q[0].length - 1, out = [], i, j;
  for(i=0;i<=nx;i++)   out.push(Q[i][0].slice());
  for(j=1;j<=ny;j++)   out.push(Q[nx][j].slice());
  for(i=nx-1;i>=0;i--) out.push(Q[i][ny].slice());
  for(j=ny-1;j>=1;j--) out.push(Q[0][j].slice());
  return out;
}
function cruzaChapa(P, Q, xAlvo){
  var out = [], j, i;
  for(j=0;j<P[0].length;j++){
    for(i=0;i+1<P.length;i++){
      var a = P[i][j][0] - xAlvo, b = P[i+1][j][0] - xAlvo;
      if(a === 0){ out.push(Q[i][j].slice()); break; }
      if(a*b < 0){
        var t = a/(a - b);
        out.push([ Q[i][j][0] + (Q[i+1][j][0]-Q[i][j][0])*t,
                   Q[i][j][1] + (Q[i+1][j][1]-Q[i][j][1])*t ]);
        break;
      }
    }
  }
  return out.length >= 2 ? out : null;
}

/* ------------------------------------------------------------ a baliza ---- */
/* Uma baliza JÁ é plana — o "planificar" dela é só desenhá-la em verdadeira
   grandeza. Sai o gabarito do cavername: as duas metades, linha de centro,
   linha de base, linha d'água e as marcas das costuras. */
function desenhoBaliza(nome, meia, costuras, calado, zBase){
  var i, pts = [], linhas = [];
  var z0 = zBase;                             /* linha de base do casco */
  for(i=meia.length-1;i>=0;i--) pts.push([-meia[i][0], meia[i][1] - z0]);
  for(i=1;i<meia.length;i++)    pts.push([ meia[i][0], meia[i][1] - z0]);

  var maxY = 0, maxZ = -Infinity, minZ = Infinity;
  for(i=0;i<pts.length;i++){
    if(Math.abs(pts[i][0]) > maxY) maxY = Math.abs(pts[i][0]);
    if(pts[i][1] > maxZ) maxZ = pts[i][1];
    if(pts[i][1] < minZ) minZ = pts[i][1];
  }
  if(!(maxY > 0)) maxY = 1;
  /* leva a origem para o canto: x = boca/2 + y,  y = altura acima da base */
  for(i=0;i<pts.length;i++) pts[i] = [pts[i][0] + maxY, pts[i][1]];

  linhas.push({ pts: [[maxY, 0], [maxY, maxZ]], tipo: 'eixo' });          /* centro */
  linhas.push({ pts: [[0, 0], [2*maxY, 0]], tipo: 'eixo' });              /* base   */
  if(calado > z0 && calado - z0 < maxZ)
    linhas.push({ pts: [[0, calado - z0], [2*maxY, calado - z0]], tipo: 'agua' });
  if(costuras && costuras.length){
    for(i=0;i<costuras.length;i++){
      var y = costuras[i][0], z = costuras[i][1] - z0, d = Math.max(6, maxY*0.02);
      linhas.push({ pts: [[maxY - y - d, z], [maxY - y + d, z]], tipo: 'baliza' });
      linhas.push({ pts: [[maxY + y - d, z], [maxY + y + d, z]], tipo: 'baliza' });
    }
  }
  return {
    nome: nome, sub: 'gabarito do casco em chapas', larg: 2*maxY, alt: maxZ,
    contorno: { pts: pts, fechado: false },
    linhas: linhas,
    info: [ 'boca ' + Math.round(2*maxY) + ' mm', 'altura ' + Math.round(maxZ) + ' mm' ]
  };
}

/* ------------------------------------------------------------- arrumação --
   Empacotamento por prateleiras: enche a linha até a largura disponível e
   quebra. Todo desenho é encostado num CRUZAMENTO da malha, senão contar
   quadrados a partir do canto não funciona. */
function arruma(desenhos, largMM, folgaMM, modulo){
  var linhas = [], atual = [], x = 0, y = 0, altLinha = 0, i;
  function sobe(v){ return modulo ? Math.ceil(v/modulo)*modulo : v; }
  for(i=0;i<desenhos.length;i++){
    var d = desenhos[i];
    if(atual.length && x + d.larg > largMM + 1e-6){
      linhas.push({ itens: atual, alt: altLinha });
      y += sobe(altLinha + folgaMM);
      atual = []; x = 0; altLinha = 0;
    }
    atual.push({ d: d, x: x, y: y });
    x = sobe(x + d.larg + folgaMM);
    if(d.alt > altLinha) altLinha = d.alt;
  }
  if(atual.length){ linhas.push({ itens: atual, alt: altLinha }); y += sobe(altLinha + folgaMM); }
  var itens = [], maxX = 0;
  linhas.forEach(function(L){ L.itens.forEach(function(it){
    it.altLinha = L.alt;
    itens.push(it);
    if(it.x + it.d.larg > maxX) maxX = it.x + it.d.larg;
  }); });
  return { itens: itens, larg: maxX, alt: Math.max(0, y - folgaMM) };
}

/* A lista completa: primeiro as chapas, depois os gabaritos de baliza. */
function montaDesenhos(chapas, estacoes, balizas, calado, zBase){
  var out = [], i;
  for(i=0;i<chapas.length;i++) if(chapas[i].pronta) out.push(desenhoChapa(chapas[i], estacoes));
  for(i=0;i<balizas.length;i++)
    out.push(desenhoBaliza(balizas[i].nome, balizas[i].meia, balizas[i].costuras, calado, zBase));
  return out;
}

/* ===== pdf.js ===== */
/* ============================================================================
   Escritor de PDF mínimo, sem biblioteca — a página tem de continuar sendo um
   arquivo só, sem rede.

   Sai PDF 1.4 vetorial: linha é linha, texto é texto Helvetica. Nada de
   imagem, então o desenho é do tamanho de um e-mail e imprime nítido em
   qualquer escala.

   Cuidado que define a implementação inteira: o arquivo é montado como VETOR
   DE BYTES, não como string. A tabela xref é uma lista de deslocamentos em
   bytes, e um "ã" numa string JavaScript vira DOIS bytes em UTF-8 — bastaria
   um acento num rótulo para todos os deslocamentos saírem errados e o PDF
   abrir corrompido. Aqui o texto é convertido para WinAnsi byte a byte.
   ========================================================================== */

/* Unicode -> WinAnsiEncoding para o que não é Latin-1 puro. */
var WINANSI = { 0x20AC:0x80, 0x201A:0x82, 0x0192:0x83, 0x201E:0x84, 0x2026:0x85,
  0x2020:0x86, 0x2021:0x87, 0x02C6:0x88, 0x2030:0x89, 0x0160:0x8A, 0x2039:0x8B,
  0x0152:0x8C, 0x017D:0x8E, 0x2018:0x91, 0x2019:0x92, 0x201C:0x93, 0x201D:0x94,
  0x2022:0x95, 0x2013:0x96, 0x2014:0x97, 0x02DC:0x98, 0x2122:0x99, 0x0161:0x9A,
  0x203A:0x9B, 0x0153:0x9C, 0x017E:0x9E, 0x0178:0x9F };
var TROCA = { 0x2192:'->', 0x2190:'<-', 0x00D7:'x', 0x00B7:'.', 0x2261:'=' };

function bytesTexto(s){
  var out = [], i, c, u;
  for(i=0;i<s.length;i++){
    u = s.charCodeAt(i);
    if(TROCA[u]){ var t = TROCA[u], k; for(k=0;k<t.length;k++) out.push(t.charCodeAt(k)); continue; }
    if(WINANSI[u]) c = WINANSI[u];
    else if(u <= 0xFF) c = u;
    else c = 0x3F;                                  /* ? */
    if(c === 0x28 || c === 0x29 || c === 0x5C) out.push(0x5C);   /* ( ) \ */
    out.push(c);
  }
  return out;
}

function PDFDoc(){
  var buf = [], objs = [], atual = null;
  function crua(s){ for(var i=0;i<s.length;i++) buf.push(s.charCodeAt(i) & 0xFF); }
  return {
    buf: buf, objs: objs,
    crua: crua,
    texto: function(s){ var b = bytesTexto(s), i; for(i=0;i<b.length;i++) buf.push(b[i]); },
    obj: function(n){ objs[n] = buf.length; crua(n + ' 0 obj\n'); },
    fim: function(){ crua('endobj\n'); }
  };
}

/* --------------------------------------------------------- fluxo de página */
function PDFPagina(){
  var op = [];
  function n(v){ return (Math.round(v*1000)/1000).toString(); }
  return {
    op: op,
    largura: function(w){ op.push(n(w) + ' w'); },
    cinza: function(g){ op.push(n(g) + ' G'); },
    preenche: function(g){ op.push(n(g) + ' g'); },
    tracejado: function(a, b){ op.push(a ? '[' + n(a) + ' ' + n(b) + '] 0 d' : '[] 0 d'); },
    poli: function(pts, fechar){
      if(!pts.length) return;
      op.push(n(pts[0][0]) + ' ' + n(pts[0][1]) + ' m');
      for(var i=1;i<pts.length;i++) op.push(n(pts[i][0]) + ' ' + n(pts[i][1]) + ' l');
      if(fechar) op.push('h');
      op.push('S');
    },
    linha: function(x1, y1, x2, y2){
      op.push(n(x1) + ' ' + n(y1) + ' m ' + n(x2) + ' ' + n(y2) + ' l S');
    },
    ret: function(x, y, w, h, preencher){
      op.push(n(x) + ' ' + n(y) + ' ' + n(w) + ' ' + n(h) + ' re ' + (preencher ? 'f' : 'S'));
    },
    txt: function(x, y, s, tam){
      op.push('BT /F1 ' + n(tam) + ' Tf 1 0 0 1 ' + n(x) + ' ' + n(y) + ' Tm');
      op.push('__TXT__' + s);
      op.push('Tj ET');
    }
  };
}

/* ------------------------------------------------------------ montagem ---- */
function montaPDF(paginas){
  var d = PDFDoc(), i, j;
  var nObj = 2 + paginas.length*2 + 1;              /* catalogo, pages, N*(pag+fluxo), fonte */
  var idFonte = nObj;
  d.crua('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');

  d.obj(1); d.crua('<< /Type /Catalog /Pages 2 0 R >>\n'); d.fim();
  d.obj(2);
  var kids = [];
  for(i=0;i<paginas.length;i++) kids.push((3 + i*2) + ' 0 R');
  d.crua('<< /Type /Pages /Kids [' + kids.join(' ') + '] /Count ' + paginas.length + ' >>\n'); d.fim();

  for(i=0;i<paginas.length;i++){
    var p = paginas[i], idP = 3 + i*2, idC = idP + 1;
    d.obj(idP);
    d.crua('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' +
           (Math.round(p.wPt*100)/100) + ' ' + (Math.round(p.hPt*100)/100) + '] ' +
           '/Resources << /Font << /F1 ' + idFonte + ' 0 R >> >> /Contents ' + idC + ' 0 R >>\n');
    d.fim();

    /* o fluxo vai byte a byte: os rótulos têm acento */
    var corpo = [];
    for(j=0;j<p.op.length;j++){
      var o = p.op[j], k;
      if(o.indexOf('__TXT__') === 0){
        corpo.push(0x28);                              /* ( */
        var b = bytesTexto(o.slice(7));
        for(k=0;k<b.length;k++) corpo.push(b[k]);
        corpo.push(0x29);                              /* ) */
      } else {
        for(k=0;k<o.length;k++) corpo.push(o.charCodeAt(k) & 0xFF);
      }
      corpo.push(0x0A);
    }
    d.obj(idC);
    d.crua('<< /Length ' + corpo.length + ' >>\nstream\n');
    for(j=0;j<corpo.length;j++) d.buf.push(corpo[j]);
    d.crua('endstream\n'); d.fim();
  }

  d.obj(idFonte);
  d.crua('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\n');
  d.fim();

  var inicioXref = d.buf.length;
  d.crua('xref\n0 ' + (nObj + 1) + '\n');
  d.crua('0000000000 65535 f \n');
  for(i=1;i<=nObj;i++){
    var off = d.objs[i] || 0;
    var s = '0000000000' + off;
    d.crua(s.slice(s.length - 10) + ' 00000 n \n');
  }
  d.crua('trailer\n<< /Size ' + (nObj + 1) + ' /Root 1 0 R >>\nstartxref\n' + inicioXref + '\n%%EOF\n');
  return new Uint8Array(d.buf);
}

/* ===== prancha.js ===== */
/* ============================================================================
   Da lista de desenhos para as pgPranchas do 

   Uma prancha por desenho. Se na escala pedida o desenho não couber na folha,
   ele é LADRILHADO: cada folha traz um pedaço, com 10 mm de sobreposição para
   colar e cruzetas de registro nos cantos. É assim que se leva um traçado de
   6 m para uma impressora de escritório.

   A escala nunca sai quebrada. "Ajustar à página" escolhe a maior escala
   REDONDA que cabe — 1:20, 1:25, 1:50 — porque numa escala como 1:13,7 não se
   conta quadrado nem se confere medida com trena.
   ========================================================================== */


var PT_MM = 72/25.4;                                   /* milímetro em pontos */
var FOLHAS = { A4: [210, 297], A3: [297, 420], A2: [420, 594] };
var DENOM = [1, 2, 2.5, 4, 5, 8, 10, 16, 20, 25, 40, 50, 100, 200, 250, 500, 1000, 2000];

function escalaRedonda(escMax){
  var i, melhor = 1/DENOM[DENOM.length-1];
  for(i=0;i<DENOM.length;i++) if(1/DENOM[i] <= escMax){ melhor = 1/DENOM[i]; break; }
  return melhor;
}
function rotuloEscala(esc){
  var d = 1/esc;
  if(Math.abs(d - Math.round(d)) < 1e-6) return '1:' + Math.round(d);
  return '1:' + d.toFixed(1).replace('.', ',');
}

/* ------------------------------------------------------------- uma folha -- */
function pgSelo(pg, W, H, m, tit, sub, dir, pe){
  pg.largura(0.5); pg.cinza(0.35);
  pg.linha(m*PT_MM, (H - m - 9)*PT_MM, (W - m)*PT_MM, (H - m - 9)*PT_MM);
  pg.preenche(0);
  pg.txt(m*PT_MM, (H - m - 6.5)*PT_MM, tit, 11);
  if(sub){ pg.preenche(0.35); pg.txt(m*PT_MM, (H - m - 13.5)*PT_MM, sub, 7.5); }
  if(dir){
    pg.preenche(0.2);
    pg.txt((W - m - larguraTxt(dir, 8))*PT_MM, (H - m - 6.5)*PT_MM, dir, 8);
  }
  pg.preenche(0.45);
  pg.txt(m*PT_MM, (m - 3.5)*PT_MM, pe, 6.5);
  pg.preenche(0);
}
/* Largura aproximada em Helvetica: 0,52 em por caractere serve para alinhar
   um rótulo à direita sem carregar a tabela de larguras da fonte. */
function larguraTxt(s, tam){ return s.length*tam*0.52/PT_MM; }

function pgMalha(pg, ox, oy, esc, mod, x0, y0, x1, y1){
  var i, gx, gy;
  pg.tracejado(0);
  for(gx = Math.floor(x0/mod)*mod; gx <= x1 + 1e-6; gx += mod){
    var forte = Math.abs(gx/mod) % 5 < 1e-6;
    pg.largura(forte ? 0.6 : 0.3); pg.cinza(forte ? 0.4 : 0.7);
    pg.linha(ox + gx*esc*PT_MM, oy + y0*esc*PT_MM, ox + gx*esc*PT_MM, oy + y1*esc*PT_MM);
  }
  for(gy = Math.floor(y0/mod)*mod; gy <= y1 + 1e-6; gy += mod){
    var f2 = Math.abs(gy/mod) % 5 < 1e-6;
    pg.largura(f2 ? 0.6 : 0.3); pg.cinza(f2 ? 0.4 : 0.7);
    pg.linha(ox + x0*esc*PT_MM, oy + gy*esc*PT_MM, ox + x1*esc*PT_MM, oy + gy*esc*PT_MM);
  }
}

function pgDesenho(pg, d, ox, oy, esc){
  var i;
  function P(p){ return [ox + p[0]*esc*PT_MM, oy + p[1]*esc*PT_MM]; }
  /* linhas auxiliares primeiro, contorno por cima */
  for(i=0;i<d.linhas.length;i++){
    var L = d.linhas[i];
    if(L.tipo === 'geratriz'){ pg.largura(0.2); pg.cinza(0.62); pg.tracejado(0); }
    else if(L.tipo === 'baliza'){ pg.largura(0.45); pg.cinza(0.25); pg.tracejado(0); }
    else if(L.tipo === 'eixo'){ pg.largura(0.55); pg.cinza(0.28); pg.tracejado(3.5, 2); }
    else { pg.largura(0.45); pg.cinza(0.45); pg.tracejado(1.6, 1.4); }
    pg.poli(L.pts.map(P), false);
  }
  pg.tracejado(0);
  pg.largura(1.0); pg.cinza(0);
  pg.poli(d.contorno.pts.map(P), d.contorno.fechado);
}

/* --------------------------------------------------- montaPDF todas as folhas */
function pgPranchas(desenhos, opt){
  opt = opt || {};
  var folha = FOLHAS[opt.folha || 'A3'] || FOLHAS.A3;
  var paisagem = opt.orientacao !== 'retrato';
  var W = paisagem ? folha[1] : folha[0];
  var H = paisagem ? folha[0] : folha[1];
  var m = opt.margem || 12;
  var topo = 17, rodape = 6;                        /* pgSelo e rodapé, em mm */
  var uw = W - 2*m, uh = H - 2*m - topo - rodape;
  var SOBRE = 10;                                    /* sobreposição ao ladrilhar */
  var paginas = [];
  var pe = opt.rodape || 'Brana · Projetos Navais';

  desenhos.forEach(function(d, idx){
    var escMax = Math.min(uw/Math.max(1, d.larg), uh/Math.max(1, d.alt));
    var esc = opt.escala ? opt.escala : escalaRedonda(escMax);
    var mod = moduloMalha(esc, 6);
    var largPapel = d.larg*esc, altPapel = d.alt*esc;
    var passoX = Math.max(10, uw - SOBRE), passoY = Math.max(10, uh - SOBRE);
    var nc = Math.max(1, Math.ceil((largPapel - uw)/passoX) + 1);
    var nr = Math.max(1, Math.ceil((altPapel - uh)/passoY) + 1);
    if(largPapel <= uw + 1e-6) nc = 1;
    if(altPapel  <= uh + 1e-6) nr = 1;

    for(var r=0;r<nr;r++) for(var c=0;c<nc;c++){
      var pg = PDFPagina();
      var dir = rotuloEscala(esc) + '   quadrado ' + mod + ' mm' +
                (nc*nr > 1 ? '   folha ' + (c+1) + '/' + nc + ' x ' + (r+1) + '/' + nr : '');
      pgSelo(pg, W, H, m, d.nome + (d.sub ? '  -  ' + d.sub : ''),
           (d.info || []).join('   ·   '), dir,
           pe + '   ·   ' + (opt.titulo || '') + '   ·   desenho ' + (idx+1) + ' de ' + desenhos.length);

      var areaX = m*PT_MM, areaY = (m + rodape)*PT_MM, areaW = uw*PT_MM, areaH = uh*PT_MM;
      pg.op.push('q');
      pg.op.push((areaX).toFixed(2) + ' ' + (areaY).toFixed(2) + ' ' +
                 (areaW).toFixed(2) + ' ' + (areaH).toFixed(2) + ' re W n');

      /* origem do desenho nesta folha */
      /* numa folha so o desenho vai CENTRADO na area util; ladrilhado, ele
         comeca no canto para as folhas casarem. */
      var cx = (nc === 1) ? (uw - largPapel)/2*PT_MM : 0;
      var cy = (nr === 1) ? (uh - altPapel)/2*PT_MM : 0;
      var ox = areaX + cx - c*passoX*PT_MM, oy = areaY + cy - r*passoY*PT_MM;
      /* limites do trecho visível, em mm de desenho */
      var x0 = Math.max(0, c*passoX/esc - mod), x1 = Math.min(d.larg, (c*passoX + uw)/esc + mod);
      var y0 = Math.max(0, r*passoY/esc - mod), y1 = Math.min(d.alt,  (r*passoY + uh)/esc + mod);
      pgMalha(pg, ox, oy, esc, mod, x0, y0, x1, y1);
      pgDesenho(pg, d, ox, oy, esc);
      pg.op.push('Q');

      /* cruzetas de registro quando ladrilhado */
      if(nc*nr > 1){
        pg.largura(0.4); pg.cinza(0.3); pg.tracejado(0);
        [[areaX, areaY], [areaX + areaW, areaY], [areaX, areaY + areaH], [areaX + areaW, areaY + areaH]]
          .forEach(function(p){
            pg.linha(p[0] - 4*PT_MM, p[1], p[0] + 4*PT_MM, p[1]);
            pg.linha(p[0], p[1] - 4*PT_MM, p[0], p[1] + 4*PT_MM);
          });
        pg.tracejado(2, 2); pg.cinza(0.6); pg.largura(0.3);
        if(c < nc-1) pg.linha(areaX + areaW - SOBRE*PT_MM, areaY, areaX + areaW - SOBRE*PT_MM, areaY + areaH);
        if(r < nr-1) pg.linha(areaX, areaY + areaH - SOBRE*PT_MM, areaX + areaW, areaY + areaH - SOBRE*PT_MM);
        pg.tracejado(0);
      }
      /* régua de conferência: 100 mm reais no papel */
      pg.largura(0.6); pg.cinza(0); pg.tracejado(0);
      var Lr = Math.min(100, uw*0.4), yr = (m + 1.2)*PT_MM;
      pg.linha((W - m - Lr)*PT_MM, yr, (W - m)*PT_MM, yr);
      pg.linha((W - m - Lr)*PT_MM, yr - 1.5*PT_MM, (W - m - Lr)*PT_MM, yr + 1.5*PT_MM);
      pg.linha((W - m)*PT_MM, yr - 1.5*PT_MM, (W - m)*PT_MM, yr + 1.5*PT_MM);
      pg.preenche(0.3);
      pg.txt((W - m - Lr - larguraTxt(Lr + ' mm no papel', 6.5) - 2)*PT_MM, yr - 2*PT_MM, Lr + ' mm no papel', 6.5);
      pg.preenche(0);

      paginas.push({ wPt: W*PT_MM, hPt: H*PT_MM, op: pg.op });
    }
  });
  return paginas;
}

/* ------------------------------------------------------------------- pgCapa */
function pgCapa(opt, linhasResumo, tabelas){
  var folha = FOLHAS[opt.folha || 'A3'] || FOLHAS.A3;
  var paisagem = opt.orientacao !== 'retrato';
  var W = paisagem ? folha[1] : folha[0], H = paisagem ? folha[0] : folha[1];
  var m = opt.margem || 12;
  var pg = PDFPagina();
  pg.preenche(0);
  pg.txt(m*PT_MM, (H - m - 8)*PT_MM, opt.titulo || 'Relatório de planificação', 17);
  pg.largura(0.6); pg.cinza(0.3);
  pg.linha(m*PT_MM, (H - m - 13)*PT_MM, (W - m)*PT_MM, (H - m - 13)*PT_MM);
  var y = H - m - 22;
  pg.preenche(0.25);
  (linhasResumo || []).forEach(function(l){ pg.txt(m*PT_MM, y*PT_MM, l, 9); y -= 5.2; });
  y -= 4;
  (tabelas || []).forEach(function(T){
    pg.preenche(0); pg.txt(m*PT_MM, y*PT_MM, T.titulo, 10); y -= 5.5;
    pg.largura(0.4); pg.cinza(0.5);
    pg.linha(m*PT_MM, (y + 1.6)*PT_MM, (W - m)*PT_MM, (y + 1.6)*PT_MM);
    var col = T.col, larguras = T.larg;
    pg.preenche(0.35);
    var x = m;
    col.forEach(function(c, i){ pg.txt(x*PT_MM, (y - 3)*PT_MM, c, 7); x += larguras[i]; });
    y -= 8;
    pg.preenche(0.1);
    T.linhas.forEach(function(L){
      x = m;
      L.forEach(function(v, i){ pg.txt(x*PT_MM, y*PT_MM, String(v), 7.5); x += larguras[i]; });
      y -= 4.6;
    });
    y -= 6;
  });
  pg.preenche(0.45);
  pg.txt(m*PT_MM, (m - 3.5)*PT_MM, (opt.rodape || 'Brana · Projetos Navais'), 6.5);
  return { wPt: W*PT_MM, hPt: H*PT_MM, op: pg.op };
}

function geraPDF(desenhos, opt, linhasResumo, tabelas){
  var pgs = [];
  if(linhasResumo) pgs.push(pgCapa(opt, linhasResumo, tabelas));
  pgs = pgs.concat(pgPranchas(desenhos, opt));
  var b = montaPDF(pgs);
  b.folhas = pgs.length;
  return b;
}
